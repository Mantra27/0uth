#!/bin/bash

# Source directory containing .js files
source_dir="../"

# Destination directory to copy .js files
destination_dir="../build/"

# Find all .js files in the source directory and its subdirectories
js_files=$(find "$source_dir" -type f -name "*.js")

# Loop through each .js file
for js_file in $js_files; do
  # Get the relative path of the file from the source directory
  relative_path="${js_file#$source_dir/}"

  # Create the destination folder path
  destination_folder="$destination_dir/$(dirname "$relative_path")"

  # Create the destination folder if it doesn't exist
  mkdir -p "$destination_folder"

  # Copy the .js file to the destination folder
  cp "$js_file" "$destination_folder"
done

echo "All .js files copied to destination directory: $destination_dir"
